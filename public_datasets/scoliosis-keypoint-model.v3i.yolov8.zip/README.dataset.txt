# scoliosis-keypoint-model > 2025-06-01 3:12pm
https://universe.roboflow.com/cobacoba-vjxyv/scoliosis-keypoint-model-ahvid

Provided by a Roboflow user
License: CC BY 4.0

